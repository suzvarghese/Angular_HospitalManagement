export class Reception {
}
