import { CommonModule } from '@angular/common';
import { Component, OnInit, signal } from '@angular/core';
import { FormsModule, NgForm } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { AppointmentBill } from '../../../models/appointment-bill';
import { AppointmentBill as AppointmentBillService } from '../../../services/appointment-bill';
import { Payment } from '../../../models/payment';
// import { PaymentService } from '../../../services/payment';
import { PaymentApiService as PaymentService } from '../../../services/payment';

@Component({
  selector: 'app-collect-payment',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './collect-payment.html',
  styleUrl: './collect-payment.scss',
})
export class CollectPayment implements OnInit {

  // Pending Bills
  pendingBills: AppointmentBill[] = [];
  selectedBillId: number = 0;
  selectedBill: AppointmentBill | null = null;

  // Payment fields
  paymentMethod: string = '';
  paidAmount: number = 0;

  // State
  isLoadingBills = signal<boolean>(false);
  isSaving = signal<boolean>(false);
  successMessage = signal<string>('');
  errorMessage = signal<string>('');

  // Completed payment + the bill it was for (used to render the printable receipt)
  completedPayment = signal<Payment | null>(null);
  receiptBill: AppointmentBill | null = null;

  // billId to auto-select, passed in via ?billId= from the bill-generate page
  private preselectBillId: number = 0;

  constructor(
    private appointmentBillService: AppointmentBillService,
    private paymentService: PaymentService,
    private route: ActivatedRoute
  ) { }

  ngOnInit(): void {
    this.preselectBillId = Number(this.route.snapshot.queryParamMap.get('billId')) || 0;
    this.loadPendingBills();
  }

  // Load Appointment Bills whose Payment Status is Pending
  loadPendingBills(): void {
    this.isLoadingBills.set(true);
    this.errorMessage.set('');

    this.appointmentBillService.getAllAppointmentBills().subscribe({
      next: (response: AppointmentBill[]) => {
        this.pendingBills = response.filter(bill => bill.PaymentStatus === 'Pending');
        this.isLoadingBills.set(false);

        // Auto-select the bill passed from the bill-generate page, if any
        if (this.preselectBillId) {
          this.selectedBillId = this.preselectBillId;
          this.onBillChange();
        }
      },
      error: (err: any) => {
        console.log(err);
        this.isLoadingBills.set(false);
        this.errorMessage.set('Failed to load appointment bills');
      }
    });
  }

  // Select Appointment Bill
  onBillChange(): void {
    this.selectedBill = this.pendingBills.find(
      bill => bill.AppointmentBillId === Number(this.selectedBillId)
    ) ?? null;

    if (this.selectedBill) {
      this.paidAmount = this.selectedBill.TotalAmount;
    }
  }

  // Submit Payment
collectPayment(paymentForm: NgForm): void {
    this.successMessage.set('');
    this.errorMessage.set('');

    if (!this.selectedBill) {
      this.errorMessage.set('Please select an appointment bill');
      return;
    }
    if (!this.paymentMethod) {
      this.errorMessage.set('Please select a payment method');
      return;
    }
    if (!this.paidAmount || this.paidAmount <= 0) {
      this.errorMessage.set('Please enter a valid paid amount');
      return;
    }

    const payment: Payment = new Payment();
    payment.ReceptionistId = 1;
    payment.AppointmentBillId = this.selectedBill.AppointmentBillId;
    payment.PaidAmount = this.paidAmount;
    payment.PaymentMethod = this.paymentMethod;
    payment.PaidAt = new Date().toISOString();
    payment.Status = 'Paid';

    this.isSaving.set(true);

    const billForReceipt = this.selectedBill;

    this.paymentService.addPayment(payment).subscribe({
      next: (response: Payment) => {
        this.isSaving.set(false);
        this.successMessage.set('Payment collected successfully!');

        this.completedPayment.set(response);
        this.receiptBill = billForReceipt;

        // REFRESH PENDING BILLS - IMPORTANT
        this.loadPendingBills();

        this.resetForm(paymentForm);
      },
      error: (err: any) => {
        console.log(err);
        this.isSaving.set(false);
        this.errorMessage.set('Sorry! Failed to collect payment');
      }
    });
}

  // Print the receipt (see @media print rules in collect-payment.scss)
  printReceipt(): void {
    window.print();
  }

  // Start a fresh payment collection after printing / dismissing the receipt
  startNewPayment(): void {
    this.completedPayment.set(null);
    this.receiptBill = null;
    this.successMessage.set('');
  }

  // Clear the form
  resetForm(paymentForm?: NgForm): void {
    this.selectedBillId = 0;
    this.selectedBill = null;
    this.paymentMethod = '';
    this.paidAmount = 0;

    if (paymentForm) {
      paymentForm.resetForm();
    }
  }
}