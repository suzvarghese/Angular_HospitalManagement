export class LabTest {
}
