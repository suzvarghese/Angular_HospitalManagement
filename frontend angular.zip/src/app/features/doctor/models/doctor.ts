export class Doctor {
}
