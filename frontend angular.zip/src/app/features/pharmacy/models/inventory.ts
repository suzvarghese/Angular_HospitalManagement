export class Inventory {
}
